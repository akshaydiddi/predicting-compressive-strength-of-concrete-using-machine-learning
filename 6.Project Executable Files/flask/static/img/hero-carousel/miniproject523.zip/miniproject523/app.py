from flask import Flask, render_template, request,url_for,redirect,session
import pickle
import os
import re

model = pickle.load(open('fuel.pkl','rb'))
app = Flask(__name__, template_folder='templates')

@app.route('/')
def home():
    return render_template('index.html')
# @app.route('/y_predict',methods=['GET'])
# def predict():
#     return render_template('y_predict.html')

# @app.route('/y_predict',methods=['POST'])
# def y_predict():
#     x_test=[[float(x) for x in request.form.values()]]
#     print('actual',x_test)
#     pred=model.predict(x_test)
#     return render_template('y_predict.html', \
#                            prediction_text=('Car fuel Consumption(L/100km) \
#                                              : ',pred[0]))
if __name__=='__main__':
    app.run(host='0.0.0.0',debug=True)